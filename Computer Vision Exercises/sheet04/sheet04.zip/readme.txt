Run using: python task01.py, python task02.py

Group Members
Rhys Agombar
Thiago Bell Felix de Oliveira
